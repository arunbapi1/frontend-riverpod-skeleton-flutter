 

import 'dart:io';
import 'package:architecture_demo/riverpod_methods/riverpod_methods.dart';
import 'package:architecture_demo/src/api_services/api_services.dart';
import 'package:architecture_demo/src/model/user_model.dart';
import 'package:architecture_demo/utility/shared_preferance_utility.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';


final userDataProvider = FutureProvider<List<Data>>((ref) async {
  return ref.watch(userProvider).getUsers();
});


final networkProvider = StateNotifierProvider<NetworkNotifier, bool>((ref) {
  return NetworkNotifier();
});

final navigatorKeyProvider = Provider<GlobalKey<NavigatorState>>((ref) {
  return GlobalKey<NavigatorState>();
});

final loadingProvider = StateNotifierProvider<LoadingNotifier, bool>((ref) {
  return LoadingNotifier();
});

final selectedUserProvider = StateProvider<Data?>((ref) => null);


final exampleValueProvider = StateNotifierProvider<ExampleValueNotifier, String?>((ref) {
  final preferencesService = ref.watch(preferencesServiceProvider);
  return ExampleValueNotifier(preferencesService);
});


//Alert Dialog Text 
// final dialogTextProvider = StateProvider<String>((ref) => 'Initial Text');
final alertMessageProvider = StateProvider<String?>((ref) => null);


final preferencesServiceProvider = Provider<PreferencesService>((ref) {
  return PreferencesService();
});


final authProvider = StateProvider<bool>((ref) => false);


class NetworkNotifier extends StateNotifier<bool> {
  NetworkNotifier() : super(false) {
    _checkNetworkStatus();
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      _checkNetworkStatus();
    });
  }

  Future<void> _checkNetworkStatus() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        state = true;
      } else {
        state = false;
      }
    } on SocketException catch (_) {
      state = false;
    }
  }
}
