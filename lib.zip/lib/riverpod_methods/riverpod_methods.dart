import 'package:architecture_demo/utility/shared_preferance_utility.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class LoadingNotifier extends StateNotifier<bool> {
  LoadingNotifier() : super(false);

  void startLoading() {
    state = true;
  }

  void stopLoading() {
    state = false;
  }
}



class ExampleValueNotifier extends StateNotifier<String?> {
  final PreferencesService _preferencesService;

  ExampleValueNotifier(this._preferencesService) : super(null) {
    _loadExampleValue();
  }

  Future<void> _loadExampleValue() async {
    final exampleValue = await _preferencesService.getExampleValue();
    state = exampleValue;
  }

  Future<void> setExampleValue(String value) async {
    await _preferencesService.saveExampleValue(value);
    state = value;
  }
}

