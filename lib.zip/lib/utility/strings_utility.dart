import 'package:flutter/material.dart';

class Strings {


static const HEADING_LABEL_TEXT = "Skeleton Demo";

}